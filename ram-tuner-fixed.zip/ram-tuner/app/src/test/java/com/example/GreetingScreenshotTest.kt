package com.example

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.unit.dp
import com.example.model.MemoryStats
import com.example.model.ShizukuStatus
import com.example.ui.components.MemoryStatusCard
import com.example.ui.components.ShizukuStatusCard
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    composeTestRule.setContent {
      MyApplicationTheme {
        Column(modifier = Modifier.padding(16.dp)) {
          MemoryStatusCard(
            memoryStats = MemoryStats(
              totalBytes = 3221225472L,
              availableBytes = 1073741824L,
              usedBytes = 2147483648L,
              thresholdBytes = 268435456L,
              isLowMemory = false,
              isLowRamDevice = true,
              usedPercentage = 66.7f,
              totalFormatted = "3.0 GB",
              availableFormatted = "1.0 GB",
              usedFormatted = "2.0 GB"
            ),
            androidVersionName = "Android 14 (API 34)",
            deviceModel = "Budget Phone",
            isTrimming = false,
            onTrimMemory = {}
          )
          ShizukuStatusCard(
            status = ShizukuStatus(
              isInstalled = true,
              isRunning = true,
              isPermissionGranted = true,
              hasWriteSecureSettings = false,
              canExecutePrivileged = true,
              statusMessageMy = "Shizuku ချိတ်ဆက်ထားပြီး ဖြစ်သည်",
              statusMessageEn = "Shizuku active & authorized"
            ),
            onRequestPermission = {},
            onShowSetupGuide = {}
          )
        }
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}
