package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.DeepCleanManager
import com.example.data.SystemSettingsManager
import com.example.model.DeepCleanResult
import com.example.model.DeepCleanScheduleConfig
import com.example.model.SettingResult
import com.example.shizuku.ShizukuHelper
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun testAppNameResource() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("RAM Tuner", appName)
    }

    @Test
    fun testFailClosedWhenPermissionMissing() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val shizukuHelper = ShizukuHelper(context)
        val manager = SystemSettingsManager(context, shizukuHelper)

        val settings = manager.getAllSettings()
        val windowAnimSetting = settings.first { it.key == "window_animation_scale" }

        val result = manager.applySetting(windowAnimSetting, "0.5")

        assertNotNull(result)
        assertEquals("window_animation_scale", result.key)
        assertEquals("0.5", result.requestedValue)
        if (!result.ok) {
            assertNotNull(result.reason)
            assertTrue(result.reason!!.isNotEmpty())
        }
    }

    @Test
    fun testMemoryStatsCalculation() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val shizukuHelper = ShizukuHelper(context)
        val manager = SystemSettingsManager(context, shizukuHelper)

        val stats = manager.getMemoryStats()
        assertNotNull(stats)
        assertTrue(stats.totalFormatted.isNotEmpty())
        assertTrue(stats.availableFormatted.isNotEmpty())
        assertTrue(stats.usedPercentage in 0f..100f)
    }

    @Test
    fun testSettingResultJsonProof() {
        val result = SettingResult(
            ok = true,
            key = "window_animation_scale",
            requestedValue = "0.5",
            verifiedValue = "0.5",
            reason = null,
            timestamp = 1726789000000L
        )

        val json = result.toJsonProof()
        assertTrue(json.contains("\"ok\": true"))
        assertTrue(json.contains("\"key\": \"window_animation_scale\""))
        assertTrue(json.contains("\"requested_value\": \"0.5\""))
        assertTrue(json.contains("\"verified_value\": \"0.5\""))
    }

    @Test
    fun testSettingsCatalogCoversLowRamOptimizations() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val shizukuHelper = ShizukuHelper(context)
        val manager = SystemSettingsManager(context, shizukuHelper)

        val settings = manager.getAllSettings()
        val keys = settings.map { it.key }

        assertTrue("Should include window animation scale", keys.contains("window_animation_scale"))
        assertTrue("Should include transition animation scale", keys.contains("transition_animation_scale"))
        assertTrue("Should include animator duration scale", keys.contains("animator_duration_scale"))
        assertTrue("Should include disable window blurs", keys.contains("disable_window_blurs"))
        assertTrue("Should include cached apps freezer", keys.contains("cached_apps_freezer"))

        for (setting in settings) {
            assertTrue("Guide location must not be empty for ${setting.key}", setting.guideLocation.isNotEmpty())
            assertTrue("Title in Burmese must not be empty", setting.titleMy.isNotEmpty())
            assertTrue("Options must contain at least 2 choices", setting.options.size >= 2)
        }
    }

    @Test
    fun testDeepCleanConfigPersistence() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val shizukuHelper = ShizukuHelper(context)
        val manager = DeepCleanManager(context, shizukuHelper)

        val initial = manager.getConfig()
        assertNotNull(initial)

        val newConfig = DeepCleanScheduleConfig(
            enabled = true,
            intervalHours = 12L,
            requireCharging = true,
            requireDeviceIdle = false
        )
        manager.saveConfig(newConfig)

        val readback = manager.getConfig()
        assertTrue(readback.enabled)
        assertEquals(12L, readback.intervalHours)
        assertTrue(readback.requireCharging)
        assertFalse(readback.requireDeviceIdle)
    }

    @Test
    fun testDeepCleanExecutionFailClosedWithoutShizuku() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val shizukuHelper = ShizukuHelper(context)
        val manager = DeepCleanManager(context, shizukuHelper)

        // In standard test environment without Shizuku service running, execution must fail-closed
        val result = manager.executeDeepClean()
        assertNotNull(result)
        assertFalse(result.ok)
        assertNotNull(result.reason)
        assertTrue(result.reason!!.contains("Shizuku"))
    }

    @Test
    fun testDeepCleanResultJsonProof() {
        val result = DeepCleanResult(
            ok = true,
            timestamp = 1726789000000L,
            freedRamBytes = 367001600L,
            freedRamFormatted = "350 MB",
            cachesCleared = true,
            processesKilled = true,
            memoryTrimmed = true,
            beforeAvailableRam = "850 MB",
            afterAvailableRam = "1.2 GB",
            reason = null,
            commandsExecuted = listOf("pm trim-caches 999999999999", "am kill-all", "am trim-empty", "sync")
        )

        val json = result.toJsonProof()
        assertTrue(json.contains("\"ok\": true"))
        assertTrue(json.contains("\"freed_ram\": \"350 MB\""))
        assertTrue(json.contains("\"caches_cleared\": true"))
        assertTrue(json.contains("\"processes_managed\": true"))
        assertTrue(json.contains("pm trim-caches"))
    }
}
