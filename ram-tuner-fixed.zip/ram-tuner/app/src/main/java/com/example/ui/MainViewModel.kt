package com.example.ui

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.DeepCleanManager
import com.example.data.SystemSettingsManager
import com.example.model.*
import com.example.shizuku.ShizukuHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MainUiState(
    val memoryStats: MemoryStats = MemoryStats(),
    val shizukuStatus: ShizukuStatus = ShizukuStatus(),
    val settingsList: List<SettingItem> = emptyList(),
    val selectedCategory: SettingCategory? = null,
    val activeGuideItem: SettingItem? = null,
    val lastResult: SettingResult? = null,
    val deepCleanConfig: DeepCleanScheduleConfig = DeepCleanScheduleConfig(),
    val isDeepCleaning: Boolean = false,
    val lastDeepCleanResult: DeepCleanResult? = null,
    val isOptimizingAll: Boolean = false,
    val isTrimming: Boolean = false,
    val androidVersionName: String = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
    val deviceModel: String = "${Build.MANUFACTURER} ${Build.MODEL}"
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val shizukuHelper = ShizukuHelper(application)
    val settingsManager = SystemSettingsManager(application, shizukuHelper)
    val deepCleanManager = DeepCleanManager(application, shizukuHelper)

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            val mem = settingsManager.getMemoryStats()
            val shizuku = settingsManager.getShizukuStatus()
            val settings = settingsManager.getAllSettings()
            val cleanConfig = deepCleanManager.getConfig()

            _uiState.update { current ->
                current.copy(
                    memoryStats = mem,
                    shizukuStatus = shizuku,
                    settingsList = settings,
                    deepCleanConfig = cleanConfig
                )
            }
        }
    }

    fun requestShizukuPermission() {
        val requested = shizukuHelper.requestPermission()
        if (!requested) {
            refresh()
        }
    }

    fun toggleDeepClean(enabled: Boolean) {
        val updated = _uiState.value.deepCleanConfig.copy(enabled = enabled)
        deepCleanManager.saveConfig(updated)
        _uiState.update { it.copy(deepCleanConfig = updated) }
    }

    fun setDeepCleanInterval(hours: Long) {
        val updated = _uiState.value.deepCleanConfig.copy(intervalHours = hours)
        deepCleanManager.saveConfig(updated)
        _uiState.update { it.copy(deepCleanConfig = updated) }
    }

    fun toggleDeepCleanIdle(requireIdle: Boolean) {
        val updated = _uiState.value.deepCleanConfig.copy(requireDeviceIdle = requireIdle)
        deepCleanManager.saveConfig(updated)
        _uiState.update { it.copy(deepCleanConfig = updated) }
    }

    fun toggleDeepCleanCharging(requireCharging: Boolean) {
        val updated = _uiState.value.deepCleanConfig.copy(requireCharging = requireCharging)
        deepCleanManager.saveConfig(updated)
        _uiState.update { it.copy(deepCleanConfig = updated) }
    }

    fun runManualDeepClean() {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update { it.copy(isDeepCleaning = true) }
            val result = deepCleanManager.executeDeepClean()
            if (result.ok) {
                vibrateConfirmation()
            }
            val updatedConfig = deepCleanManager.getConfig()
            val updatedMem = settingsManager.getMemoryStats()

            _uiState.update { current ->
                current.copy(
                    isDeepCleaning = false,
                    lastDeepCleanResult = result,
                    deepCleanConfig = updatedConfig,
                    memoryStats = updatedMem
                )
            }
        }
    }

    fun dismissDeepCleanResult() {
        _uiState.update { it.copy(lastDeepCleanResult = null) }
    }

    fun applySetting(item: SettingItem, targetValue: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = settingsManager.applySetting(item, targetValue)
            if (result.ok) {
                vibrateConfirmation()
            }
            val updatedSettings = settingsManager.getAllSettings()
            val updatedMem = settingsManager.getMemoryStats()

            _uiState.update { current ->
                current.copy(
                    lastResult = result,
                    settingsList = updatedSettings,
                    memoryStats = updatedMem
                )
            }
        }
    }

    fun applySmoothPreset() {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update { it.copy(isOptimizingAll = true) }
            val currentSettings = settingsManager.getAllSettings()
            var allOk = true
            val successList = mutableListOf<String>()
            val failedList = mutableListOf<String>()

            for (item in currentSettings) {
                if (item.currentValue != item.recommendedValue) {
                    val res = settingsManager.applySetting(item, item.recommendedValue)
                    if (res.ok) {
                        successList.add(item.key)
                    } else {
                        allOk = false
                        failedList.add("${item.key}: ${res.reason}")
                    }
                }
            }

            if (allOk && successList.isNotEmpty()) {
                vibrateConfirmation()
            }

            val updatedSettings = settingsManager.getAllSettings()
            val updatedMem = settingsManager.getMemoryStats()

            val combinedResult = SettingResult(
                ok = allOk,
                key = "smooth_ram_preset",
                requestedValue = "Apply Recommended Settings",
                verifiedValue = if (successList.isNotEmpty()) "ပြောင်းလဲပြီး: ${successList.joinToString(", ")}" else "အားလုံး အကြံပြုထားပြီးဖြစ်သည်",
                reason = if (failedList.isNotEmpty()) failedList.joinToString("\n") else null
            )

            _uiState.update { current ->
                current.copy(
                    isOptimizingAll = false,
                    lastResult = combinedResult,
                    settingsList = updatedSettings,
                    memoryStats = updatedMem
                )
            }
        }
    }

    fun trimMemory() {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update { it.copy(isTrimming = true) }
            val result = settingsManager.trimMemory()
            if (result.ok) {
                vibrateConfirmation()
            }
            val updatedMem = settingsManager.getMemoryStats()
            _uiState.update { current ->
                current.copy(
                    isTrimming = false,
                    lastResult = result,
                    memoryStats = updatedMem
                )
            }
        }
    }

    fun selectCategory(category: SettingCategory?) {
        _uiState.update { it.copy(selectedCategory = category) }
    }

    fun showGuide(item: SettingItem) {
        _uiState.update { it.copy(activeGuideItem = item) }
    }

    fun dismissGuide() {
        _uiState.update { it.copy(activeGuideItem = null) }
    }

    fun dismissResult() {
        _uiState.update { it.copy(lastResult = null) }
    }

    private fun vibrateConfirmation() {
        try {
            val context = getApplication<Application>()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(70, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                @Suppress("DEPRECATION")
                vibrator?.vibrate(70)
            }
        } catch (_: Throwable) {
        }
    }

    override fun onCleared() {
        super.onCleared()
        shizukuHelper.cleanup()
    }
}
