package com.example.data

import android.app.ActivityManager
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import androidx.work.*
import com.example.model.DeepCleanResult
import com.example.model.DeepCleanScheduleConfig
import com.example.shizuku.ShizukuHelper
import com.example.work.DeepCleanWorker
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class DeepCleanManager(
    private val context: Context,
    private val shizukuHelper: ShizukuHelper
) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("deep_clean_prefs", Context.MODE_PRIVATE)

    fun getConfig(): DeepCleanScheduleConfig {
        return DeepCleanScheduleConfig(
            enabled = prefs.getBoolean(KEY_ENABLED, false),
            intervalHours = prefs.getLong(KEY_INTERVAL, 6L),
            requireCharging = prefs.getBoolean(KEY_REQUIRE_CHARGING, false),
            requireDeviceIdle = prefs.getBoolean(KEY_REQUIRE_IDLE, true),
            clearSystemCaches = prefs.getBoolean(KEY_CLEAR_CACHES, true),
            killBackgroundProcesses = prefs.getBoolean(KEY_KILL_BG, true),
            trimMemory = prefs.getBoolean(KEY_TRIM_MEMORY, true),
            lastRunTimestamp = prefs.getLong(KEY_LAST_TIMESTAMP, 0L),
            lastFreedRamBytes = prefs.getLong(KEY_LAST_FREED_BYTES, 0L),
            lastFreedRamFormatted = prefs.getString(KEY_LAST_FREED_FORMATTED, "0 MB") ?: "0 MB",
            lastStatusMessage = prefs.getString(KEY_LAST_STATUS, "မလုပ်ဆောင်ရသေးပါ (Never run)") ?: "မလုပ်ဆောင်ရသေးပါ"
        )
    }

    fun saveConfig(config: DeepCleanScheduleConfig) {
        prefs.edit()
            .putBoolean(KEY_ENABLED, config.enabled)
            .putLong(KEY_INTERVAL, config.intervalHours)
            .putBoolean(KEY_REQUIRE_CHARGING, config.requireCharging)
            .putBoolean(KEY_REQUIRE_IDLE, config.requireDeviceIdle)
            .putBoolean(KEY_CLEAR_CACHES, config.clearSystemCaches)
            .putBoolean(KEY_KILL_BG, config.killBackgroundProcesses)
            .putBoolean(KEY_TRIM_MEMORY, config.trimMemory)
            .apply()

        applySchedule(config)
    }

    fun applySchedule(config: DeepCleanScheduleConfig): Boolean {
        return try {
            val workManager = WorkManager.getInstance(context)
            if (!config.enabled) {
                workManager.cancelUniqueWork(WORK_NAME)
                return true
            }

            val constraintsBuilder = Constraints.Builder()
                .setRequiresCharging(config.requireCharging)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                constraintsBuilder.setRequiresDeviceIdle(config.requireDeviceIdle)
            }

            val periodicRequest = PeriodicWorkRequestBuilder<DeepCleanWorker>(
                config.intervalHours, TimeUnit.HOURS
            )
                .setConstraints(constraintsBuilder.build())
                .build()

            workManager.enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                periodicRequest
            )
            true
        } catch (e: Throwable) {
            android.util.Log.w("DeepCleanManager", "WorkManager schedule not applied: ${e.message}")
            false
        }
    }

    fun executeDeepClean(): DeepCleanResult {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memBefore = ActivityManager.MemoryInfo().apply { activityManager?.getMemoryInfo(this) }
        val beforeAvailFormatted = formatBytes(memBefore.availMem)

        val isShizukuReady = shizukuHelper.isShizukuRunning() && shizukuHelper.isPermissionGranted()

        if (!isShizukuReady) {
            return DeepCleanResult(
                ok = false,
                freedRamBytes = 0L,
                freedRamFormatted = "0 MB",
                cachesCleared = false,
                processesKilled = false,
                memoryTrimmed = false,
                beforeAvailableRam = beforeAvailFormatted,
                afterAvailableRam = beforeAvailFormatted,
                reason = "Shizuku ခွင့်ပြုချက် မရှိသေးပါ (Shizuku permission required for system cache clearing and background process kill)",
                commandsExecuted = emptyList()
            )
        }

        val commandsRun = mutableListOf<String>()
        var cachesCleared = false
        var processesKilled = false
        var memoryTrimmed = false

        // 1. System-level cache clearing
        val cacheRes = shizukuHelper.executeShell("pm trim-caches 999999999999")
        if (cacheRes.ok) {
            cachesCleared = true
            commandsRun.add("pm trim-caches 999999999999")
        }

        // 2. Kill safe background processes
        val killRes = shizukuHelper.executeShell("am kill-all")
        if (killRes.ok) {
            processesKilled = true
            commandsRun.add("am kill-all")
        }

        // 3. Trim empty process allocations
        val trimRes = shizukuHelper.executeShell("am trim-empty")
        if (trimRes.ok) {
            memoryTrimmed = true
            commandsRun.add("am trim-empty")
        }

        // 4. Flush filesystem buffers
        shizukuHelper.executeShell("sync")
        commandsRun.add("sync")

        // CRITICAL READBACK: Query actual system memory stats after operation
        val memAfter = ActivityManager.MemoryInfo().apply { activityManager?.getMemoryInfo(this) }
        val afterAvailFormatted = formatBytes(memAfter.availMem)
        val freedBytes = (memAfter.availMem - memBefore.availMem).coerceAtLeast(0L)
        val freedFormatted = formatBytes(freedBytes)

        val now = System.currentTimeMillis()
        val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(now))
        val statusMsg = "အောင်မြင်ပါသည် (Freed $freedFormatted at $dateStr)"

        // Persist last run record
        prefs.edit()
            .putLong(KEY_LAST_TIMESTAMP, now)
            .putLong(KEY_LAST_FREED_BYTES, freedBytes)
            .putString(KEY_LAST_FREED_FORMATTED, freedFormatted)
            .putString(KEY_LAST_STATUS, statusMsg)
            .apply()

        return DeepCleanResult(
            ok = true,
            timestamp = now,
            freedRamBytes = freedBytes,
            freedRamFormatted = freedFormatted,
            cachesCleared = cachesCleared,
            processesKilled = processesKilled,
            memoryTrimmed = memoryTrimmed,
            beforeAvailableRam = beforeAvailFormatted,
            afterAvailableRam = afterAvailFormatted,
            reason = null,
            commandsExecuted = commandsRun
        )
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 MB"
        val mb = bytes.toDouble() / (1024.0 * 1024.0)
        val gb = mb / 1024.0
        val df = DecimalFormat("#,##0.#")
        return if (gb >= 1.0) {
            "${df.format(gb)} GB"
        } else {
            "${df.format(mb)} MB"
        }
    }

    companion object {
        const val WORK_NAME = "AUTOMATED_DEEP_CLEAN_WORK"
        private const val KEY_ENABLED = "key_deep_clean_enabled"
        private const val KEY_INTERVAL = "key_deep_clean_interval"
        private const val KEY_REQUIRE_CHARGING = "key_deep_clean_charging"
        private const val KEY_REQUIRE_IDLE = "key_deep_clean_idle"
        private const val KEY_CLEAR_CACHES = "key_deep_clean_clear_caches"
        private const val KEY_KILL_BG = "key_deep_clean_kill_bg"
        private const val KEY_TRIM_MEMORY = "key_deep_clean_trim_mem"
        private const val KEY_LAST_TIMESTAMP = "key_deep_clean_last_timestamp"
        private const val KEY_LAST_FREED_BYTES = "key_deep_clean_last_freed_bytes"
        private const val KEY_LAST_FREED_FORMATTED = "key_deep_clean_last_freed_formatted"
        private const val KEY_LAST_STATUS = "key_deep_clean_last_status"
    }
}
