package com.example.work

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.data.DeepCleanManager
import com.example.shizuku.ShizukuHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class DeepCleanWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        Log.d(TAG, "Starting scheduled automated Deep Clean work...")
        val shizukuHelper = ShizukuHelper(applicationContext)
        val deepCleanManager = DeepCleanManager(applicationContext, shizukuHelper)

        try {
            val result = deepCleanManager.executeDeepClean()
            Log.d(TAG, "Deep Clean completed: ok=${result.ok}, freed=${result.freedRamFormatted}")
            if (result.ok) {
                Result.success()
            } else {
                Result.retry()
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Deep Clean execution failed", e)
            Result.failure()
        }
    }

    companion object {
        private const val TAG = "DeepCleanWorker"
    }
}
