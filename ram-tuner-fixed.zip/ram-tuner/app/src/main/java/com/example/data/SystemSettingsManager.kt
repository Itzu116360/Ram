package com.example.data

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import com.example.model.*
import com.example.shizuku.ShizukuHelper
import java.text.DecimalFormat

class SystemSettingsManager(
    private val context: Context,
    private val shizukuHelper: ShizukuHelper
) {

    fun getMemoryStats(): MemoryStats {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager?.getMemoryInfo(memoryInfo)

        val total = memoryInfo.totalMem
        val avail = memoryInfo.availMem
        val used = (total - avail).coerceAtLeast(0L)
        val threshold = memoryInfo.threshold
        val isLow = memoryInfo.lowMemory
        val isLowRam = activityManager?.isLowRamDevice ?: false

        val usedPercent = if (total > 0) (used.toFloat() / total.toFloat()) * 100f else 0f

        return MemoryStats(
            totalBytes = total,
            availableBytes = avail,
            usedBytes = used,
            thresholdBytes = threshold,
            isLowMemory = isLow,
            isLowRamDevice = isLowRam,
            usedPercentage = usedPercent,
            totalFormatted = formatBytes(total),
            availableFormatted = formatBytes(avail),
            usedFormatted = formatBytes(used)
        )
    }

    fun getShizukuStatus(): ShizukuStatus {
        val installed = shizukuHelper.isShizukuInstalled()
        val running = shizukuHelper.isShizukuRunning()
        val granted = shizukuHelper.isPermissionGranted()
        val secureGranted = context.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

        val canPrivileged = granted || secureGranted

        val (msgMy, msgEn) = when {
            granted -> "Shizuku ချိတ်ဆက်ထားပြီး ဖြစ်သည် (Settings များကို တိုက်ရိုက် ပြောင်းလဲနိုင်ပါသည်)" to "Shizuku active & authorized (Privileged access ready)"
            running && !granted -> "Shizuku ဖွင့်ထားသော်လည်း ခွင့်ပြုချက် (Permission) မပေးရသေးပါ" to "Shizuku is running, but permission is required"
            !running && installed -> "Shizuku အက်ပ်ရှိသော်လည်း Service မဖွင့်ရသေးပါ (Wireless Debugging ဖြင့် ဖွင့်ပါ)" to "Shizuku installed, but service is not running"
            secureGranted -> "WRITE_SECURE_SETTINGS ခွင့်ပြုချက် ရရှိထားပါသည်" to "WRITE_SECURE_SETTINGS permission granted directly via ADB"
            else -> "Shizuku မရှိပါ (သို့မဟုတ်) ADB ဖြင့် ခွင့်ပြုချက် မပေးရသေးပါ" to "Shizuku inactive. Connect via Wireless Debugging or ADB"
        }

        return ShizukuStatus(
            isInstalled = installed,
            isRunning = running,
            isPermissionGranted = granted,
            hasWriteSecureSettings = secureGranted,
            canExecutePrivileged = canPrivileged,
            statusMessageMy = msgMy,
            statusMessageEn = msgEn
        )
    }

    fun readCurrentValue(key: String, type: SettingType): String {
        return try {
            when (type) {
                SettingType.GLOBAL -> Settings.Global.getString(context.contentResolver, key) ?: ""
                SettingType.SYSTEM -> Settings.System.getString(context.contentResolver, key) ?: ""
                SettingType.SECURE -> Settings.Secure.getString(context.contentResolver, key) ?: ""
                SettingType.DEVICE_CONFIG -> {
                    if (shizukuHelper.isPermissionGranted()) {
                        val res = shizukuHelper.executeShell("device_config get activity_manager $key")
                        if (res.ok && res.output != "null") res.output else ""
                    } else {
                        Settings.Global.getString(context.contentResolver, key) ?: ""
                    }
                }
                SettingType.SHELL_COMMAND -> ""
            }
        } catch (e: Throwable) {
            ""
        }
    }

    fun applySetting(item: SettingItem, targetValue: String): SettingResult {
        val key = item.key
        val status = getShizukuStatus()

        if (!status.canExecutePrivileged) {
            return SettingResult(
                ok = false,
                key = key,
                requestedValue = targetValue,
                verifiedValue = readCurrentValue(key, item.type),
                reason = "ခွင့်ပြုချက် မရှိသေးပါ (Permission missing). Shizuku ဖွင့်ပြီး ခွင့်ပြုချက် ပေးပါ သို့မဟုတ် ADB ဖြင့် WRITE_SECURE_SETTINGS ပေးပါ။"
            )
        }

        var executionError: String? = null

        // Try direct Settings API if WRITE_SECURE_SETTINGS is granted
        var directSuccess = false
        if (status.hasWriteSecureSettings) {
            try {
                directSuccess = when (item.type) {
                    SettingType.GLOBAL -> Settings.Global.putString(context.contentResolver, key, targetValue)
                    SettingType.SYSTEM -> Settings.System.putString(context.contentResolver, key, targetValue)
                    SettingType.SECURE -> Settings.Secure.putString(context.contentResolver, key, targetValue)
                    else -> false
                }
            } catch (e: Throwable) {
                executionError = e.localizedMessage
            }
        }

        // If direct API did not succeed or not available, use Shizuku shell
        if (!directSuccess && status.isPermissionGranted) {
            val shellCmd = when (item.type) {
                SettingType.GLOBAL -> "settings put global $key $targetValue"
                SettingType.SYSTEM -> "settings put system $key $targetValue"
                SettingType.SECURE -> "settings put secure $key $targetValue"
                SettingType.DEVICE_CONFIG -> "device_config put activity_manager $key $targetValue"
                SettingType.SHELL_COMMAND -> "$key $targetValue"
            }
            val shellResult = shizukuHelper.executeShell(shellCmd)
            if (!shellResult.ok) {
                executionError = shellResult.error ?: "Shell command returned code ${shellResult.exitCode}"
            }
        }

        // CRITICAL READBACK VERIFICATION:
        val readback = readCurrentValue(key, item.type)

        // Compare target and readback
        val isVerified = if (item.type == SettingType.DEVICE_CONFIG && !status.isPermissionGranted) {
            // Cannot read device_config without root/shizuku, but if direct or command succeeded
            directSuccess
        } else {
            readback.trim().equals(targetValue.trim(), ignoreCase = true)
        }

        return if (isVerified) {
            SettingResult(
                ok = true,
                key = key,
                requestedValue = targetValue,
                verifiedValue = readback,
                reason = null
            )
        } else {
            SettingResult(
                ok = false,
                key = key,
                requestedValue = targetValue,
                verifiedValue = readback,
                reason = executionError ?: "စနစ်တွင် စစ်ဆေးချက်အရ တန်ဖိုးမပြောင်းသေးပါ (System readback: '$readback' != '$targetValue')"
            )
        }
    }

    fun trimMemory(): SettingResult {
        val status = getShizukuStatus()
        val beforeStats = getMemoryStats()

        if (!status.isPermissionGranted && !status.hasWriteSecureSettings) {
            return SettingResult(
                ok = false,
                key = "trim_memory",
                requestedValue = "trim-empty",
                verifiedValue = null,
                reason = "Shizuku ခွင့်ပြုချက် လိုအပ်ပါသည်။ (Shizuku permission required for am trim-empty)"
            )
        }

        val res = if (status.isPermissionGranted) {
            shizukuHelper.executeShell("am trim-empty")
        } else {
            // best-effort local GC
            System.gc()
            com.example.shizuku.ShellExecutionResult(true, 0, "System GC executed")
        }

        val afterStats = getMemoryStats()
        val freedBytes = (afterStats.availableBytes - beforeStats.availableBytes).coerceAtLeast(0L)
        val freedFormatted = formatBytes(freedBytes)

        return SettingResult(
            ok = res.ok,
            key = "trim_memory",
            requestedValue = "trim-empty",
            verifiedValue = "ရရှိနိုင်သော RAM: ${afterStats.availableFormatted} (လွတ်သွားသော RAM: $freedFormatted)",
            reason = res.error
        )
    }

    fun getAllSettings(): List<SettingItem> {
        return listOf(
            SettingItem(
                id = "window_animation_scale",
                key = "window_animation_scale",
                type = SettingType.GLOBAL,
                titleMy = "Window Animation Scale (ဝင်းဒိုး အန်နီမေးရှင်း)",
                titleEn = "Window Animation Scale",
                descriptionMy = "Window များ ပွင့်/ပိတ်ချိန် အန်နီမေးရှင်း အမြန်နှုန်း။ 0.5x သို့မဟုတ် 0x (Off) ထားခြင်းဖြင့် GPU composition နှင့် RAM buffering ဝန်ကို ချက်ချင်း လျှော့ချပေးပါသည်။",
                descriptionEn = "Controls window opening/closing speed. Setting to 0.5x or 0x drastically reduces GPU buffer allocation and surface composition lag.",
                guideLocation = "Settings > System > Developer options > Drawing > Window animation scale",
                category = SettingCategory.ANIMATION,
                options = listOf(
                    SettingOption("0.5x (အကြံပြုချက်)", "0.5", isRecommended = true, note = "အလွန်သွက်လက်ပြီး ချောမွေ့စေသည်"),
                    SettingOption("0x (Off ပိတ်မည်)", "0.0", note = "အန်နီမေးရှင်း လုံးဝမသုံးဘဲ ချက်ချင်းပွင့်စေသည်"),
                    SettingOption("1.0x (မူလ)", "1.0", note = "Android Standard"),
                    SettingOption("1.5x (နှေး)", "1.5", note = "အန်နီမေးရှင်း ကြာချိန် ပိုကြာစေသည်")
                ),
                currentValue = readCurrentValue("window_animation_scale", SettingType.GLOBAL).ifEmpty { "1.0" },
                recommendedValue = "0.5"
            ),
            SettingItem(
                id = "transition_animation_scale",
                key = "transition_animation_scale",
                type = SettingType.GLOBAL,
                titleMy = "Transition Animation Scale (စာမျက်နှာ ကူးပြောင်းမှု)",
                titleEn = "Transition Animation Scale",
                descriptionMy = "Screen တစ်ခုမှ တစ်ခုသို့ ကူးပြောင်းရာတွင် နှောင့်နှေးမှု မရှိစေဘဲ ချက်ချင်း ကူးပြောင်းစေပါသည်။ Low-RAM ဖုန်းများတွင် Frame Drop ဖြစ်ခြင်းကို အထူးသက်သာစေပါသည်။",
                descriptionEn = "Controls transitions between screens and activities. 0.5x eliminates stutter and frame drops on budget chipsets.",
                guideLocation = "Settings > System > Developer options > Drawing > Transition animation scale",
                category = SettingCategory.ANIMATION,
                options = listOf(
                    SettingOption("0.5x (အကြံပြုချက်)", "0.5", isRecommended = true, note = "Transition အမြန်နှုန်း မြှင့်တင်သည်"),
                    SettingOption("0x (Off ပိတ်မည်)", "0.0", note = "ကူးပြောင်းမှု အန်နီမေးရှင်း ပိတ်မည်"),
                    SettingOption("1.0x (မူလ)", "1.0", note = "Android Standard")
                ),
                currentValue = readCurrentValue("transition_animation_scale", SettingType.GLOBAL).ifEmpty { "1.0" },
                recommendedValue = "0.5"
            ),
            SettingItem(
                id = "animator_duration_scale",
                key = "animator_duration_scale",
                type = SettingType.GLOBAL,
                titleMy = "Animator Duration Scale (ခလုတ် & UI အန်နီမေးရှင်း)",
                titleEn = "Animator Duration Scale",
                descriptionMy = "ခလုတ်များ နှိပ်သည့်အခါနှင့် မီနူးများ ပြသချိန် အန်နီမေးရှင်း ကြာချိန်။ 0.5x ထားရှိခြင်းဖြင့် ဖုန်းတုန့်ပြန်မှု (touch responsiveness) သိသိသာသာ လျင်မြန်လာပါမည်။",
                descriptionEn = "Scales durations of in-app UI motion and widget ripples. 0.5x creates instant tactile responsiveness and cuts CPU render cycles.",
                guideLocation = "Settings > System > Developer options > Drawing > Animator duration scale",
                category = SettingCategory.ANIMATION,
                options = listOf(
                    SettingOption("0.5x (အကြံပြုချက်)", "0.5", isRecommended = true, note = "တုံ့ပြန်မှု မြန်ဆန်စေသည်"),
                    SettingOption("0x (Off ပိတ်မည်)", "0.0", note = "ကြာချိန် မရှိဘဲ ချက်ချင်းတုံ့ပြန်သည်"),
                    SettingOption("1.0x (မူလ)", "1.0", note = "Android Standard")
                ),
                currentValue = readCurrentValue("animator_duration_scale", SettingType.GLOBAL).ifEmpty { "1.0" },
                recommendedValue = "0.5"
            ),
            SettingItem(
                id = "disable_window_blurs",
                key = "disable_window_blurs",
                type = SettingType.GLOBAL,
                titleMy = "Disable Window Blurs (နောက်ခံ ဝါးစေသော Effect ပိတ်ရန်)",
                titleEn = "Disable Window Blurs",
                descriptionMy = "Android 12+ တွင် Quick Settings နှင့် Notification shade များ၏ နောက်ခံ ဝါးခြင်း (Gaussian blur) သည် GPU နှင့် RAM bandwidth ကို များစွာ ဝါးမျိုစေပါသည်။ ပိတ်ထားပါက ဖုန်းအလွန်ပေါ့ပါးသွားပါမည်။",
                descriptionEn = "Android 12+ real-time blurs consume massive memory bandwidth and GPU fill rate. Disabling blurs yields major FPS boost on low-RAM hardware.",
                guideLocation = "Settings > System > Developer options > Hardware accelerated rendering > Allow window-level blurs",
                category = SettingCategory.GRAPHICS,
                options = listOf(
                    SettingOption("1 (Blurs ပိတ်မည် - အကြံပြုချက်)", "1", isRecommended = true, note = "RAM & GPU ဝန် အလွန်သက်သာသည်"),
                    SettingOption("0 (Blurs ဖွင့်မည် - မူလ)", "0", note = "ပုံမှန် အမြင်လှပမှု")
                ),
                currentValue = readCurrentValue("disable_window_blurs", SettingType.GLOBAL).ifEmpty { "0" },
                recommendedValue = "1"
            ),
            SettingItem(
                id = "cached_apps_freezer",
                key = "cached_apps_freezer",
                type = SettingType.GLOBAL,
                titleMy = "Cached Apps Freezer (နောက်ခံ အက်ပ်များ အေးခဲရပ်တန့်ရန်)",
                titleEn = "Cached Apps Freezer",
                descriptionMy = "Android 11+ တွင် နောက်ခံတွင် အသုံးမပြုဘဲကျန်နေသော အက်ပ်များကို RAM/CPU မယူစေရန် kernel cgroup ဖြင့် အေးခဲ (freeze) ထားပေးသည့် စနစ်။",
                descriptionEn = "Utilizes Android Linux cgroup v2 to freeze cached background apps, preventing background battery drain and CPU/RAM hogging.",
                guideLocation = "Settings > System > Developer options > Apps > Suspend execution for cached apps",
                category = SettingCategory.MEMORY,
                options = listOf(
                    SettingOption("enabled (ဖွင့်မည် - အကြံပြုချက်)", "enabled", isRecommended = true, note = "နောက်ခံ RAM ကို ထိန်းသိမ်းပေးသည်"),
                    SettingOption("disabled (ပိတ်မည်)", "disabled", note = "နောက်ခံ လုပ်ငန်းများ ဆက်လက် run စေသည်")
                ),
                currentValue = readCurrentValue("cached_apps_freezer", SettingType.GLOBAL).ifEmpty { "disabled" },
                recommendedValue = "enabled"
            ),
            SettingItem(
                id = "max_phantom_processes",
                key = "max_phantom_processes",
                type = SettingType.DEVICE_CONFIG,
                titleMy = "Max Phantom Processes (Phantom Process ကန့်သတ်ချက်)",
                titleEn = "Max Phantom Processes Limit",
                descriptionMy = "Android 12+ ၏ Phantom Process Killer ကြောင့် နောက်ခံအက်ပ်များနှင့် ကိရိယာများ ရုတ်တရက် အပိတ်ခံရခြင်းနှင့် ပြန်ဖွင့်နေရခြင်းကို ကာကွယ်ပေးပါသည်။",
                descriptionEn = "Increases child process limit to prevent aggressive force-closures of background tasks that trigger repeated memory spikes.",
                guideLocation = "Settings > Device Config > activity_manager / Shizuku Shell",
                category = SettingCategory.MEMORY,
                options = listOf(
                    SettingOption("2147483647 (ကန့်သတ်ချက် တိုးမြှင့်မည်)", "2147483647", isRecommended = true, note = "နောက်ခံအက်ပ်များ မပြတ်တောက်စေပါ"),
                    SettingOption("32 (Android မူလ ကန့်သတ်ချက်)", "32", note = "ပုံမှန် ၃၂ ခု ကန့်သတ်ချက်")
                ),
                currentValue = readCurrentValue("max_phantom_processes", SettingType.DEVICE_CONFIG).ifEmpty { "32" },
                recommendedValue = "2147483647"
            ),
            SettingItem(
                id = "mobile_data_always_on",
                key = "mobile_data_always_on",
                type = SettingType.GLOBAL,
                titleMy = "Mobile Data Always-On (ဒေတာ အမြဲ Standby ထားခြင်း)",
                titleEn = "Mobile Data Always-On",
                descriptionMy = "Wi-Fi ချိတ်ထားစဉ် မိုဘိုင်းဒေတာ modem ကို အမြဲ standby မထားစေဘဲ ပိတ်ထားခြင်းဖြင့် RAM ပမာဏနှင့် ဘက်ထရီ သုံးစွဲမှုကို ချွေတာပေးပါသည်။",
                descriptionEn = "Disables active cellular data connection in background when Wi-Fi is connected, reducing modem buffer memory and battery usage.",
                guideLocation = "Settings > System > Developer options > Networking > Mobile data always active",
                category = SettingCategory.NETWORK_BATTERY,
                options = listOf(
                    SettingOption("0 (ပိတ်မည် - အကြံပြုချက်)", "0", isRecommended = true, note = "Wi-Fi ချိတ်ထားစဉ် RAM & ဘက်ထရီ ချွေတာသည်"),
                    SettingOption("1 (အမြဲဖွင့်မည် - မူလ)", "1", note = "ကွန်ရက် ချက်ချင်းကူးပြောင်းရန် အမြဲဖွင့်သည်")
                ),
                currentValue = readCurrentValue("mobile_data_always_on", SettingType.GLOBAL).ifEmpty { "1" },
                recommendedValue = "0"
            )
        )
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 MB"
        val mb = bytes.toDouble() / (1024.0 * 1024.0)
        val gb = mb / 1024.0
        val df = DecimalFormat("#,##0.#")
        return if (gb >= 1.0) {
            "${df.format(gb)} GB"
        } else {
            "${df.format(mb)} MB"
        }
    }
}
