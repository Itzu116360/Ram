package com.example.shizuku

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

data class ShellExecutionResult(
    val ok: Boolean,
    val exitCode: Int,
    val output: String,
    val error: String? = null
)

class ShizukuHelper(private val context: Context) {

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        Log.d(TAG, "Shizuku permission result: req=$requestCode, result=$grantResult")
    }

    init {
        try {
            Shizuku.addRequestPermissionResultListener(permissionListener)
        } catch (e: Throwable) {
            Log.w(TAG, "Failed to register Shizuku listener: ${e.message}")
        }
    }

    fun isShizukuInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        } catch (e: Throwable) {
            false
        }
    }

    fun isShizukuRunning(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (e: Throwable) {
            false
        }
    }

    fun isPermissionGranted(): Boolean {
        return try {
            if (!isShizukuRunning()) return false
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) {
            false
        }
    }

    fun requestPermission(requestCode: Int = 1001): Boolean {
        return try {
            if (!isShizukuRunning()) return false
            Shizuku.requestPermission(requestCode)
            true
        } catch (e: Throwable) {
            Log.e(TAG, "Error requesting Shizuku permission", e)
            false
        }
    }

    fun executeShell(command: String): ShellExecutionResult {
        if (!isShizukuRunning()) {
            return ShellExecutionResult(
                ok = false,
                exitCode = -1,
                output = "",
                error = "Shizuku service is not running. Please start Shizuku first."
            )
        }
        if (!isPermissionGranted()) {
            return ShellExecutionResult(
                ok = false,
                exitCode = -2,
                output = "",
                error = "Shizuku permission has not been granted."
            )
        }

        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val process = method.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val errorReader = BufferedReader(InputStreamReader(process.errorStream))
            val output = StringBuilder()
            val error = StringBuilder()

            var line: String?
            while (reader.readLine().also { line = it } != null) {
                output.append(line).append("\n")
            }
            while (errorReader.readLine().also { line = it } != null) {
                error.append(line).append("\n")
            }

            val exitCode = process.waitFor()
            val trimmedOutput = output.toString().trim()
            val trimmedError = error.toString().trim()

            ShellExecutionResult(
                ok = exitCode == 0,
                exitCode = exitCode,
                output = trimmedOutput,
                error = if (trimmedError.isNotEmpty()) trimmedError else null
            )
        } catch (e: Throwable) {
            ShellExecutionResult(
                ok = false,
                exitCode = -3,
                output = "",
                error = e.localizedMessage ?: "Process execution failed"
            )
        }
    }

    fun cleanup() {
        try {
            Shizuku.removeRequestPermissionResultListener(permissionListener)
        } catch (e: Throwable) {
            Log.w(TAG, "Failed to unregister Shizuku listener: ${e.message}")
        }
    }

    companion object {
        private const val TAG = "ShizukuHelper"
    }
}
