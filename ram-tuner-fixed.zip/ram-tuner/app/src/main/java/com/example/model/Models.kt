package com.example.model

enum class SettingCategory(val displayNameMy: String, val displayNameEn: String) {
    ANIMATION("Animations (အန်နီမေးရှင်း)", "Window, Transition & Animator"),
    MEMORY("RAM & Processes (မန်မိုရီ & နောက်ခံလုပ်ငန်း)", "App Freezer & Phantom Processes"),
    GRAPHICS("Display & Blurs (မျက်နှာပြင် & Blurs)", "GPU Blur & Visual Buffers"),
    NETWORK_BATTERY("Power & Network (ပါဝါ & ကွန်ရက်)", "Standby Optimization")
}

enum class SettingType {
    GLOBAL,
    SYSTEM,
    SECURE,
    DEVICE_CONFIG,
    SHELL_COMMAND
}

data class SettingOption(
    val label: String,
    val value: String,
    val isRecommended: Boolean = false,
    val note: String = ""
)

data class SettingItem(
    val id: String,
    val key: String,
    val type: SettingType,
    val titleMy: String,
    val titleEn: String,
    val descriptionMy: String,
    val descriptionEn: String,
    val guideLocation: String,
    val category: SettingCategory,
    val options: List<SettingOption>,
    val currentValue: String,
    val recommendedValue: String,
    val isOptimized: Boolean = currentValue == recommendedValue
)

data class MemoryStats(
    val totalBytes: Long = 0L,
    val availableBytes: Long = 0L,
    val usedBytes: Long = 0L,
    val thresholdBytes: Long = 0L,
    val isLowMemory: Boolean = false,
    val isLowRamDevice: Boolean = false,
    val usedPercentage: Float = 0f,
    val totalFormatted: String = "0 MB",
    val availableFormatted: String = "0 MB",
    val usedFormatted: String = "0 MB"
)

data class ShizukuStatus(
    val isInstalled: Boolean = false,
    val isRunning: Boolean = false,
    val isPermissionGranted: Boolean = false,
    val hasWriteSecureSettings: Boolean = false,
    val canExecutePrivileged: Boolean = false,
    val statusMessageMy: String = "",
    val statusMessageEn: String = ""
)

data class SettingResult(
    val ok: Boolean,
    val key: String,
    val requestedValue: String,
    val verifiedValue: String?,
    val reason: String?,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toJsonProof(): String {
        val escapedReason = reason?.replace("\"", "\\\"") ?: "null"
        val escapedValue = verifiedValue?.replace("\"", "\\\"") ?: "null"
        return """
            {
              "ok": $ok,
              "key": "$key",
              "requested_value": "$requestedValue",
              "verified_value": ${if (verifiedValue != null) "\"$escapedValue\"" else "null"},
              "reason": ${if (reason != null) "\"$escapedReason\"" else "null"},
              "timestamp": $timestamp
            }
        """.trimIndent()
    }
}
