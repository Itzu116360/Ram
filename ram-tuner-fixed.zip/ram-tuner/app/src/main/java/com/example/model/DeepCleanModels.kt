package com.example.model

data class DeepCleanScheduleConfig(
    val enabled: Boolean = false,
    val intervalHours: Long = 6L,
    val requireCharging: Boolean = false,
    val requireDeviceIdle: Boolean = true,
    val clearSystemCaches: Boolean = true,
    val killBackgroundProcesses: Boolean = true,
    val trimMemory: Boolean = true,
    val lastRunTimestamp: Long = 0L,
    val lastFreedRamBytes: Long = 0L,
    val lastFreedRamFormatted: String = "0 MB",
    val lastStatusMessage: String = "မလုပ်ဆောင်ရသေးပါ (Never run)"
)

data class DeepCleanResult(
    val ok: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val freedRamBytes: Long = 0L,
    val freedRamFormatted: String = "0 MB",
    val cachesCleared: Boolean = false,
    val processesKilled: Boolean = false,
    val memoryTrimmed: Boolean = false,
    val beforeAvailableRam: String = "0 MB",
    val afterAvailableRam: String = "0 MB",
    val reason: String? = null,
    val commandsExecuted: List<String> = emptyList()
) {
    fun toJsonProof(): String {
        val cmdsJson = commandsExecuted.joinToString(separator = "\", \"", prefix = "[\"", postfix = "\"]")
        val escapedReason = reason?.replace("\"", "\\\"") ?: "null"
        return """
            {
              "ok": $ok,
              "timestamp": $timestamp,
              "freed_ram": "$freedRamFormatted",
              "before_avail_ram": "$beforeAvailableRam",
              "after_avail_ram": "$afterAvailableRam",
              "caches_cleared": $cachesCleared,
              "processes_managed": $processesKilled,
              "memory_trimmed": $memoryTrimmed,
              "commands_executed": ${if (commandsExecuted.isEmpty()) "[]" else cmdsJson},
              "reason": ${if (reason != null) "\"$escapedReason\"" else "null"}
            }
        """.trimIndent()
    }
}
