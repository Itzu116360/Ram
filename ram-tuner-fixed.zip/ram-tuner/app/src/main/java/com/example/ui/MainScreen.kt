package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.SettingCategory
import com.example.ui.components.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var showShizukuGuide by remember { mutableStateOf(false) }

    val filteredSettings = remember(uiState.settingsList, uiState.selectedCategory) {
        if (uiState.selectedCategory == null) {
            uiState.settingsList
        } else {
            uiState.settingsList.filter { it.category == uiState.selectedCategory }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "RAM Tuner",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "High Android • Low RAM Optimizer",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showShizukuGuide = true },
                        modifier = Modifier.testTag("info_guide_button")
                    ) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = "Setup Guide")
                    }
                    IconButton(
                        onClick = { viewModel.refresh() },
                        modifier = Modifier.testTag("refresh_button")
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. RAM & System Status Card
            item {
                MemoryStatusCard(
                    memoryStats = uiState.memoryStats,
                    androidVersionName = uiState.androidVersionName,
                    deviceModel = uiState.deviceModel,
                    isTrimming = uiState.isTrimming,
                    onTrimMemory = { viewModel.trimMemory() }
                )
            }

            // 2. Shizuku & System Privilege Status
            item {
                ShizukuStatusCard(
                    status = uiState.shizukuStatus,
                    onRequestPermission = { viewModel.requestShizukuPermission() },
                    onShowSetupGuide = { showShizukuGuide = true }
                )
            }

            // 3. Automated Deep Clean Schedule Card
            item {
                DeepCleanCard(
                    config = uiState.deepCleanConfig,
                    isCleaning = uiState.isDeepCleaning,
                    onToggleEnabled = { viewModel.toggleDeepClean(it) },
                    onIntervalChanged = { viewModel.setDeepCleanInterval(it) },
                    onToggleIdle = { viewModel.toggleDeepCleanIdle(it) },
                    onToggleCharging = { viewModel.toggleDeepCleanCharging(it) },
                    onCleanNow = { viewModel.runManualDeepClean() }
                )
            }

            // 4. 1-Tap Smooth Preset Hero Card
            item {
                SmoothPresetCard(
                    isOptimizing = uiState.isOptimizingAll,
                    onApplyPreset = { viewModel.applySmoothPreset() }
                )
            }

            // 5. Category Filter Chips
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "System Settings ထိန်းချုပ်မှုများ",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${filteredSettings.size} ခု ရရှိနိုင်",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = uiState.selectedCategory == null,
                            onClick = { viewModel.selectCategory(null) },
                            label = { Text("အားလုံး (All)") },
                            shape = RoundedCornerShape(10.dp)
                        )
                        SettingCategory.entries.forEach { category ->
                            FilterChip(
                                selected = uiState.selectedCategory == category,
                                onClick = { viewModel.selectCategory(category) },
                                label = { Text(category.displayNameMy) },
                                shape = RoundedCornerShape(10.dp)
                            )
                        }
                    }
                }
            }

            // 6. Filtered Settings Cards
            items(filteredSettings, key = { it.id }) { item ->
                SettingCard(
                    item = item,
                    onApplyOption = { selectedVal ->
                        viewModel.applySetting(item, selectedVal)
                    },
                    onShowGuide = {
                        viewModel.showGuide(item)
                    }
                )
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Confirmation Dialog on Setting Applied
    uiState.lastResult?.let { result ->
        ConfirmationDialog(
            result = result,
            onDismiss = { viewModel.dismissResult() }
        )
    }

    // Confirmation Dialog on Deep Clean Executed
    uiState.lastDeepCleanResult?.let { deepResult ->
        DeepCleanResultDialog(
            result = deepResult,
            onDismiss = { viewModel.dismissDeepCleanResult() }
        )
    }

    // Setting Guide Dialog
    uiState.activeGuideItem?.let { guideItem ->
        SettingGuideDialog(
            item = guideItem,
            onDismiss = { viewModel.dismissGuide() }
        )
    }

    // Shizuku Setup Guide Dialog
    if (showShizukuGuide) {
        ShizukuSetupGuideDialog(
            onDismiss = { showShizukuGuide = false }
        )
    }
}
