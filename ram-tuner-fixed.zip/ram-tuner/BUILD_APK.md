# Build RAM Tuner APK

## Android Studio
1. Open this folder in Android Studio.
2. Let Gradle sync finish.
3. Select **Build > Build APK(s)**.
4. The debug APK will be under `app/build/outputs/apk/debug/`.

## Command line
From the project root:

```bash
./gradlew assembleDebug
```

The APK will be:

`app/build/outputs/apk/debug/app-debug.apk`

## Notes
- The project uses `compileSdk 36` instead of an unavailable minor API level.
- Debug builds use Android's normal debug signing; no `debug.keystore` file is required in the project.
- Release signing is optional. To create a signed release APK, provide `KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_ALIAS` (optional; defaults to `upload`), and `KEY_PASSWORD`.
- Shizuku functionality still requires Shizuku to be installed/running and the appropriate permission on the device.
- Some system-level operations may be unavailable on certain Android/ROM versions even when the APK builds successfully.
